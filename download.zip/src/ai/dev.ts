import { config } from 'dotenv';
config();

import '@/ai/flows/get-spending-insights.ts';
import '@/ai/flows/categorize-transaction.ts';