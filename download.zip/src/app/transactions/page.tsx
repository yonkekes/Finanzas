import TransactionsPage from "@/components/transactions/transactions-page";

export default function Transactions() {
    return <TransactionsPage />;
}
